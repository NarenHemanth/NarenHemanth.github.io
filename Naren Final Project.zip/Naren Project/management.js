function barOpen() {
    document.getElementById("navbar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  function barClose() {
    document.getElementById("navbar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }


  function job(description, jobName) {

    var i, jobdetails, jobsbutton ;
  
    jobdetails = document.getElementsByClassName("jobdetails");
    for (i = 0; i < jobdetails.length; i++) {
      jobdetails[i].style.display = "none";
    }

  
    jobsbutton = document.getElementsByClassName("jobsbutton");
    for (i = 0; i < jobsbutton.length; i++) {
      jobsbutton[i].className = jobsbutton[i].className.replace("active", "");
    }
  
    document.getElementById(jobName).style.display = "block";
    description.currentTarget.className += " active";
  }



  $(document).ready(function () {
    $.getJSON('./management.json', function (data) {
        console.log(data);
        $.each(data, function (key, value) {
            $('#jobContent').append("<h3>" + value.heading + "</h3>")
                             .append("<p>" + value.content + "</p>");
        });
    });
});