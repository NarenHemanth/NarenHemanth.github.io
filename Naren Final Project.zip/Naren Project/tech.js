
function populate(s1, s2, s3, s4, s5, s6) {
  loadSalaries();
}

function loadSalaries() {
  var s1 = document.getElementById('slct1');
  var s2 = document.getElementById('slct2');
  var s3 = document.getElementById('slct3');
  var s4 = document.getElementById('slct4');
  var s5 = document.getElementById('slct5');
  var s6 = document.getElementById('slct6');


  s2.innerHTML = "";
  var option = "";

  if (s1.value == "Apple Inc") {
    option = '190,000';
  }

  else if (s1.value == 'Walmart Inc') {
    option = '200,000';
  }

  else if (s1.value == 'Amazon.com Inc') {
    option = '300,000';
  }

  else if (s1.value == 'Berkshire Hathaway Inc') {
    option = '500,000';
  }

  else if (s1.value == 'Volkswagen AG') {
    option = '300,000';
  }

  s2.innerHTML += '<option value="' + option + '">' + option + '</option>';
  console.log(s2.innerHTML);


  s4.innerHTML = "";
  var option = "";

  if (s3.value == "TD Inc") {
    option = '190,000';
  }

  else if (s3.value == 'Scotiabank Inc') {
    option = '200,000';
  }

  else if (s3.value == 'Amazon.com Inc') {
    option = '300,000';
  }

  else if (s3.value == 'RBC Inc') {
    option = '500,000';
  }

  else if (s3.value == 'McKinsey & Company') {
    option = '300,000';
  }

  s4.innerHTML += '<option value="' + option + '">' + option + '</option>';
  console.log(s3.innerHTML);

  s6.innerHTML = "";
  var option = "";

  if (s5.value == "Galaxy Broadband Communications") {
    option = '190,000';
  }

  else if (s5.value == 'Samsung Electronics') {
    option = '200,000';
  }

  else if (s5.value == 'WaveStar Networks') {
    option = '210,000';
  }

  else if (s5.value == 'Pathway Communications') {
    option = '300,000';
  }

  else if (s5.value == 'Highline Mushrooms') {
    option = '200,000';
  }

  s6.innerHTML += '<option value="' + option + '">' + option + '</option>';
  console.log(s5.innerHTML);
}

