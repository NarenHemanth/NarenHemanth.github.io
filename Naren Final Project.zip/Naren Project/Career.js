function getSearch() {
    let searchValue = document.getElementById("search").value;
    if (searchValue != 'technology') {
        alert("There are no results for search value");
    }
    else {
        location.href = searchValue + ".html";
    }
}

function getLike() {
    let likebtn = document.querySelector('#likebtn');
    let result1 = document.querySelector('#result1');
    likebtn.addEventListener('click', () => {
        result1.value = parseInt(result1.value) + 1;
    })
}

function getDislike() {

    let dislikebtn = document.querySelector('#dislikebtn');
    let result2 = document.querySelector('#result2');
    dislikebtn.addEventListener('click', () => {
        result2.value = parseInt(result2.value) + 1;
    })
}
